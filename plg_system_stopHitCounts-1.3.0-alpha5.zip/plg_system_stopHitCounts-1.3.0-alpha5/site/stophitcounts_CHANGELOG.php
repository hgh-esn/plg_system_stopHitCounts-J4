<?php
/**
 * CHANGELOG
 *
 * This is the changelog for stopHitCounts.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id$
 * @package    stopHitCounts
 * @subpackage Documentation
 * @author     Hans-Guenter Heiserholt [HGH] {@link moba-hgh/joomla}
 * @author     Created on 10-Oct-2017
 */

//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for stopHitCounts

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

 * -> Security Fix
 # -> Bug Fix
 + -> Addition
 ^ -> Change
 - -> Removed
 ! -> Note
______________________________________________

10-Oct-2017 Hans-Guenter Heiserholt [HGH]
 ! Startup

*/
}//--This is the END
