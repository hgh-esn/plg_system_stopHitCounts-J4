# Stops the article-hitcounter for bots, specific users and/or acl-groups.
